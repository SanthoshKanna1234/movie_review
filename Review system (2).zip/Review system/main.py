import face_recognition as fr
import cv2 as cv
import numpy as np
import os
import HandTrackingModule as htm
import pandas as pd

df = pd.DataFrame(columns=['Name','Rating'])
path ="./students/"
known_names =[]
known_name_encodings =[]
images =os.listdir(path)
for _ in images:
    image = fr.load_image_file(path + _)
    image_path = path + _
    encoding = fr.face_encodings(image)[0]

    known_name_encodings.append(encoding)
    known_names.append(os.path.splitext(os.path.basename(image_path))[0].capitalize())

print(known_names)


folderPath = "fingers" # name of the folder, where there are images of fingers
fingerList = os.listdir(folderPath) # list of image titles in 'fingers' folder
overlayList = []
for imgPath in fingerList:
    image = cv.imread(f'{folderPath}/{imgPath}')
    overlayList.append(image)

pTime = 0


capture = cv.VideoCapture(0) #open a camera

detector = htm.handDetector(detectionCon=0.5)
totalFingers = 0

image = cv.cvtColor(image, cv.COLOR_BGR2RGB)
while True:
    boolean , frame = capture.read()  #boolean value is True if only capture a image

    img = cv.flip(frame, 1)
    img = detector.findHands(img)
    lmList, bbox = detector.findPosition(frame, draw=False)
    if lmList:
        fingersUp = detector.fingersUp()
        totalFingers = fingersUp.count(1)
        print(totalFingers)
    if boolean == True:
        grey = cv.cvtColor(frame,cv.COLOR_BGR2GRAY)  #converting BGB to Gray for High Quality 

        face_locations = fr.face_locations(frame)
        face_encodings = fr.face_encodings(frame, face_locations)

        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            matches = fr.compare_faces(known_name_encodings, face_encoding)
            name = ""

            face_distances = fr.face_distance(known_name_encodings, face_encoding)
            best_match = np.argmin(face_distances)
            name="unknow"
            if matches[best_match]:
                name = known_names[best_match]
                if name!="unknow":
                    if not any(df['Name'] == name):
                        df = pd.concat([df, pd.DataFrame({'Name': [name],'Rating':totalFingers})], ignore_index=True)
                    else:
                        index = df.index[df['Name'] == name][0]  # get the index of the row where the data exists
                        df.at[index, 'Rating'] = totalFingers  # replace the value of 'value' column for that row



            cv.rectangle(frame, (left, top), (right, bottom), (0, 0, 255), 2)
            cv.rectangle(frame, (left, bottom - 15), (right, bottom), (0, 0, 255), cv.FILLED)
            font = cv.FONT_HERSHEY_DUPLEX
            cv.putText(frame, name, (left + 6, bottom - 6), font, 1.0, (255, 255, 255), 1)
            print(totalFingers,name)


        cv.imshow("Result", frame)
        #cv.imwrite("./output.jpg", image)
        if(cv.waitKey(20)==ord('q') or cv.waitKey(20)==ord('Q')):
            break
df.to_excel('qr_data.xlsx', index=False)
capture.release()
cv.destroyAllWindows()